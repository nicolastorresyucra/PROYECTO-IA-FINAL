'''Pruebas unitarias del proyecto (ejecutar con: python -m pytest tests/ o python tests/test_proyecto.py).'''
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
import src.cnn1d_numpy as cnn
import src.datos_aire as da


def test_gradiente_cnn():
    rng = np.random.default_rng(0)
    rama = [cnn.Conv1D(3, 4, 3, rng), cnn.ReLU(), cnn.MaxPool1D(), cnn.Conv1D(4, 5, 3, rng), cnn.ReLU(), cnn.GlobalAvgPool1D()]
    modelo = cnn.RedDosEntradas(rama, [cnn.Dense(5 + 2, 4, rng), cnn.ReLU(), cnn.Dense(4, 1, rng)])
    X, E, y, w = rng.normal(size=(4, 8, 3)), rng.normal(size=(4, 2)), np.array([0, 1, 1, 0.0]), np.ones(4)
    _, dl = cnn.bce_ponderada(modelo.forward(X, E, True), y, w)
    modelo.backward(dl)
    capa = modelo.capas[0]
    i = (1, 2)
    orig = capa.params["W"][i]
    capa.params["W"][i] = orig + 1e-6; fm = cnn.bce_ponderada(modelo.forward(X, E), y, w)[0]
    capa.params["W"][i] = orig - 1e-6; fn = cnn.bce_ponderada(modelo.forward(X, E), y, w)[0]
    capa.params["W"][i] = orig
    assert abs((fm - fn) / 2e-6 - capa.grads["W"][i]) < 1e-6


def test_ventana_no_usa_el_dia_objetivo():
    dias = pd.date_range("2020-01-01", periods=6, freq="D")
    A = np.arange(1 * 6 * 24 * 3, dtype=float).reshape(1, 6, 24, 3)
    diario, _ = da.medias_diarias(A)
    muestras, X = da.construir_muestras(A, ["E"], dias, diario)
    assert (muestras["fin_ventana"] < muestras["fecha_objetivo"]).all()
    t = 3
    assert np.array_equal(X[0], A[0, t - 3:t].reshape(72, 3))


def test_limpieza_reglas():
    crudo = pd.DataFrame({"ESTACION": ["A", "A", "A"], "DISTRITO": ["D"] * 3, "LATITUD": [0] * 3, "LONGITUD": [0] * 3,
                          "ALTITUD": [0] * 3, "FECHA": [20200101] * 3, "HORA": [50000, 60000, 70000],
                          "PM10": [50.0, -1.0, 10.0], "PM2_5": [20.0, 5.0, 30.0], "NO2": [0.0, 10.0, 12.0]})
    limpio, rep = da.limpiar_datos(crudo)
    assert limpio["fecha_hora"].iloc[0] == pd.Timestamp("2020-01-01 00:00")   # UTC -> Lima
    assert np.isnan(limpio["NO2"].iloc[0]) and np.isnan(limpio["PM10"].iloc[1]) and np.isnan(limpio["PM2_5"].iloc[2])


if __name__ == "__main__":
    for nombre, f in list(globals().items()):
        if nombre.startswith("test_"):
            f(); print("[OK]", nombre)