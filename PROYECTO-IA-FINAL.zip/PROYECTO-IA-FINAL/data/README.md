# Datos

**Conjunto:** Monitoreo de los contaminantes del aire en Lima Metropolitana – [Servicio Nacional de Meteorología e Hidrología del Perú – SENAMHI]
**Fuente:** Plataforma Nacional de Datos Abiertos
https://www.datosabiertos.gob.pe/dataset/monitoreo-de-los-contaminantes-del-aire-en-lima-metropolitana-servicio-nacional-de
**Licencia:** Open Data Commons Attribution (ODC-BY). Al usarlo hay que citar al SENAMHI.

## Archivo usado en el informe

| Campo | Valor |
|---|---|
| Nombre | `Monitoreo de los contaminantes del aire en Lima Metropolitana - [Servicio Nacional de Meteorología e Hidrología del Perú - SENAMHI]_1.csv` |
| Tamaño | 68 501 558 bytes |
| SHA-256 | `896ae8a106fb128460e81b3f58096f6b9c4d582ef28fffa46e5394c5875c40d4` |
| Filas y columnas | 577 794 filas, 15 columnas |
| Fecha de corte | 31/05/2024 |
| Columnas | ID, ESTACION, FECHA, HORA, LONGITUD, LATITUD, ALTITUD, PM10, PM2_5, NO2, DEPARTAMENTO, PROVINCIA, DISTRITO, UBIGEO, FECHA_CORTE |

## Observaciones
- `HORA` está en **UTC**. El proyecto la convierte a hora de Lima (UTC−5).
- Las concentraciones están en µg/m³.

El CSV no se sube al repositorio porque pesa 65 MB. Hay que descargarlo y guardarlo en `data/raw/`.
