"""Funciones de preparación de datos para el dataset oficial del SENAMHI
"Monitoreo de los contaminantes del aire en Lima Metropolitana" (Plataforma Nacional de Datos Abiertos)."""
import numpy as np
import pandas as pd

CONTAMINANTES = ["PM10", "PM2_5", "NO2"]
DESFASE_UTC_LIMA = pd.Timedelta(hours=5)   # Lima = UTC-5 todo el año (el Perú no usa horario de verano)
UMBRAL_ECA_PM10 = 100.0                    # ECA para aire, PM10 24 h (D.S. N.° 003-2017-MINAM), en µg/m³
MIN_HORAS_DIA = 18                         # una media diaria es válida con al menos 75 % de horas (18 de 24)
VENTANA_DIAS = 3                           # la CNN mira las últimas 72 horas
MIN_HORAS_PM10_VENTANA = 54                # al menos 75 % de horas válidas de PM10 dentro de la ventana


def limpiar_datos(df_crudo):
    """Aplica las reglas de limpieza documentadas y devuelve (datos horarios limpios en hora local, reporte)."""
    df = df_crudo.copy()
    reporte = {"filas_crudas": int(len(df))}
    fecha = pd.to_datetime(df["FECHA"].astype(str), format="%Y%m%d", errors="coerce")
    hora = pd.to_numeric(df["HORA"], errors="coerce") // 10000              # HORA viene como hhmmss
    df["fecha_hora_utc"] = fecha + pd.to_timedelta(hora, unit="h")
    reporte["fechas_u_horas_invalidas"] = int(df["fecha_hora_utc"].isna().sum())
    df = df.dropna(subset=["fecha_hora_utc"])
    df["fecha_hora"] = df["fecha_hora_utc"] - DESFASE_UTC_LIMA            # el archivo está en UTC
    for c in CONTAMINANTES:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    reporte["valores_negativos_anulados"] = int((df[CONTAMINANTES] < 0).sum().sum())
    df[CONTAMINANTES] = df[CONTAMINANTES].where(df[CONTAMINANTES] >= 0)
    reporte["ceros_exactos_NO2_anulados"] = int((df["NO2"] == 0).sum())
    df.loc[df["NO2"] == 0, "NO2"] = np.nan
    incoherente = df["PM10"].notna() & df["PM2_5"].notna() & (df["PM2_5"] > 1.10 * df["PM10"])
    reporte["pares_PM25_mayor_que_PM10_anulados"] = int(incoherente.sum())
    df.loc[incoherente, ["PM10", "PM2_5"]] = np.nan
    clave = ["ESTACION", "fecha_hora"]
    n_antes = len(df)
    df = df.drop_duplicates(subset=clave + CONTAMINANTES)
    reporte["duplicados_exactos_eliminados"] = int(n_antes - len(df))
    conflicto = df.duplicated(subset=clave, keep=False)
    reporte["horas_estacion_con_valores_contradictorios"] = int(df.loc[conflicto, clave].drop_duplicates().shape[0])
    reporte["filas_contradictorias_eliminadas"] = int(conflicto.sum())
    df = df.loc[~conflicto, ["ESTACION", "DISTRITO", "LATITUD", "LONGITUD", "ALTITUD", "fecha_hora"] + CONTAMINANTES]
    reporte["filas_limpias"] = int(len(df))
    return df.sort_values(clave).reset_index(drop=True), reporte


def construir_arreglo_horario(df):
    """Ubica cada medición en una grilla completa estación x día x hora x contaminante (NaN = hora sin dato)."""
    estaciones = sorted(df["ESTACION"].unique())
    dia_inicio, dia_fin = df["fecha_hora"].min().normalize(), df["fecha_hora"].max().normalize()
    dias = pd.date_range(dia_inicio, dia_fin, freq="D")
    A = np.full((len(estaciones), len(dias), 24, len(CONTAMINANTES)), np.nan)
    for i, est in enumerate(estaciones):
        sub = df[df["ESTACION"] == est]
        idx_dia = (sub["fecha_hora"].dt.normalize() - dia_inicio).dt.days.to_numpy()
        A[i, idx_dia, sub["fecha_hora"].dt.hour.to_numpy(), :] = sub[CONTAMINANTES].to_numpy()
    return A, estaciones, dias


def media_sin_nan(x, axis):
    n = np.isfinite(x).sum(axis=axis)
    return np.where(n > 0, np.nansum(x, axis=axis) / np.maximum(n, 1), np.nan)


def maximo_sin_nan(x, axis):
    n = np.isfinite(x).sum(axis=axis)
    return np.where(n > 0, np.max(np.where(np.isfinite(x), x, -np.inf), axis=axis), np.nan)


def medias_diarias(A, min_horas=MIN_HORAS_DIA):
    """Media diaria por estación y contaminante; solo es válida con al menos `min_horas` horas medidas."""
    horas_validas = np.isfinite(A).sum(axis=2)
    return np.where(horas_validas >= min_horas, media_sin_nan(A, axis=2), np.nan), horas_validas


def construir_muestras(A, estaciones, dias, diario, ventana_dias=VENTANA_DIAS,
                       min_horas_pm10=MIN_HORAS_PM10_VENTANA, umbral=UMBRAL_ECA_PM10):
    """Una muestra = (estación, día objetivo t). Entrada: las 72 horas de los días t-3, t-2 y t-1.
    Salida: 1 si la media diaria de PM10 del día t supera el ECA (100 µg/m³), 0 en caso contrario."""
    filas, ventanas = [], []
    for i, est in enumerate(estaciones):
        for t in range(ventana_dias, len(dias)):
            v = A[i, t - ventana_dias:t].reshape(ventana_dias * 24, A.shape[-1])
            if np.isfinite(v[:, 0]).sum() < min_horas_pm10 or not np.isfinite(diario[i, t, 0]):
                continue
            filas.append({"estacion": est, "i_est": i, "fecha_objetivo": dias[t],
                          "inicio_ventana": dias[t - ventana_dias],
                          "fin_ventana": dias[t - 1] + pd.Timedelta(hours=23),
                          "pm10_objetivo": diario[i, t, 0]})
            ventanas.append(v)
    muestras = pd.DataFrame(filas)
    muestras["y"] = (muestras["pm10_objetivo"] > umbral).astype(int)
    return muestras, np.stack(ventanas)


def variables_exogenas(fechas_objetivo, i_estaciones, n_estaciones):
    """Variables conocidas de antemano: estación (one-hot) y calendario del día objetivo (codificación cíclica)."""
    fechas = pd.to_datetime(pd.Series(fechas_objetivo))
    doy, dow = fechas.dt.dayofyear.to_numpy(), fechas.dt.dayofweek.to_numpy()
    calendario = np.column_stack([np.sin(2 * np.pi * doy / 365.25), np.cos(2 * np.pi * doy / 365.25),
                                  np.sin(2 * np.pi * dow / 7), np.cos(2 * np.pi * dow / 7), (dow >= 5).astype(float)])
    return np.concatenate([np.eye(n_estaciones)[np.asarray(i_estaciones)], calendario], axis=1)


def transformar_ventanas(X_crudo, medias, desv):
    """log(1+x), estandarización con estadísticos de ENTRENAMIENTO y canales-máscara (1 = dato medido, 0 = faltante)."""
    Z = (np.log1p(X_crudo) - medias) / desv
    mascara = np.isfinite(Z).astype(float)
    return np.concatenate([np.where(np.isfinite(Z), Z, 0.0), mascara], axis=2)


def caracteristicas_resumen(X_crudo):
    """Características agregadas de la ventana para el baseline de Regresión Logística."""
    d = {}
    for c, nombre in enumerate(["pm10", "pm25", "no2"]):
        x = X_crudo[..., c]
        d[f"{nombre}_media_ultimas24h"] = media_sin_nan(x[:, 48:], 1)
        d[f"{nombre}_max_ultimas24h"] = maximo_sin_nan(x[:, 48:], 1)
        d[f"{nombre}_media_72h"] = media_sin_nan(x, 1)
        d[f"{nombre}_tendencia"] = media_sin_nan(x[:, 48:], 1) - media_sin_nan(x[:, :24], 1)
        d[f"{nombre}_media_ultimas6h"] = media_sin_nan(x[:, 66:], 1)
        d[f"{nombre}_fraccion_valida"] = np.isfinite(x).mean(1)
    return pd.DataFrame(d)


def ventana_para_fecha(A, dias, i_est, fecha_objetivo, ventana_dias=VENTANA_DIAS):
    """Extrae las 72 horas previas al día objetivo (lo que el sistema conoce al emitir la alerta)."""
    t = int((pd.Timestamp(fecha_objetivo) - dias[0]).days)
    if t < ventana_dias or t > len(dias):
        return None
    return A[i_est, t - ventana_dias:t].reshape(ventana_dias * 24, A.shape[-1])
