"""Mini librería de redes neuronales en NumPy: CNN-1D y MLP para series de tiempo.

Se implementa explícitamente la propagación hacia adelante (forward) y la retropropagación
(backward) de cada capa, de modo que el modelo es transparente, auditable y reproducible
en cualquier computadora (Google Colab, VS Code o Jupyter) sin depender de una GPU.
Formato de las series: (N muestras, L pasos de tiempo, C canales).
"""
import json
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score


class Capa:
    """Clase base: cada capa guarda sus parámetros y gradientes en diccionarios."""
    def __init__(self):
        self.params, self.grads = {}, {}

    def forward(self, x, entrenando=False):
        raise NotImplementedError

    def backward(self, dout):
        raise NotImplementedError


class Conv1D(Capa):
    """Convolución 1D con relleno 'same': (N, L, C_in) -> (N, L, C_out).
    Cada filtro de tamaño k recorre el eje del tiempo compartiendo sus pesos (im2col + producto matricial)."""
    def __init__(self, c_in, c_out, k, rng):
        super().__init__()
        self.k, self.c_out = k, c_out
        self.pad_izq, self.pad_der = (k - 1) // 2, k - 1 - (k - 1) // 2
        self.params["W"] = rng.normal(0.0, np.sqrt(2.0 / (k * c_in)), size=(k * c_in, c_out))  # inicialización He
        self.params["b"] = np.zeros(c_out)

    def forward(self, x, entrenando=False):
        N, L, C = x.shape
        xp = np.pad(x, ((0, 0), (self.pad_izq, self.pad_der), (0, 0)))
        cols = np.lib.stride_tricks.sliding_window_view(xp, self.k, axis=1)   # (N, L, C, k)
        cols = cols.transpose(0, 1, 3, 2).reshape(N, L, self.k * C)          # (N, L, k*C)
        self.forma_x, self.cols = x.shape, cols
        return cols @ self.params["W"] + self.params["b"]

    def backward(self, dout):
        N, L, C = self.forma_x
        self.grads["W"] = self.cols.reshape(-1, self.k * C).T @ dout.reshape(-1, self.c_out)
        self.grads["b"] = dout.sum(axis=(0, 1))
        dcols = (dout @ self.params["W"].T).reshape(N, L, self.k, C)
        dxp = np.zeros((N, L + self.k - 1, C))
        for j in range(self.k):
            dxp[:, j:j + L, :] += dcols[:, :, j, :]
        return dxp[:, self.pad_izq:self.pad_izq + L, :]


class ReLU(Capa):
    def forward(self, x, entrenando=False):
        self.mask = x > 0
        return x * self.mask

    def backward(self, dout):
        return dout * self.mask


class MaxPool1D(Capa):
    """Max pooling temporal de tamaño 2 y paso 2 (reduce L a la mitad; L debe ser par)."""
    def forward(self, x, entrenando=False):
        a, b = x[:, 0::2, :], x[:, 1::2, :]
        self.mask = a >= b
        return np.where(self.mask, a, b)

    def backward(self, dout):
        N, L2, C = dout.shape
        dx = np.empty((N, 2 * L2, C))
        dx[:, 0::2, :] = dout * self.mask
        dx[:, 1::2, :] = dout * ~self.mask
        return dx


class GlobalAvgPool1D(Capa):
    """Promedio global sobre el tiempo: (N, L, C) -> (N, C)."""
    def forward(self, x, entrenando=False):
        self.L = x.shape[1]
        return x.mean(axis=1)

    def backward(self, dout):
        return np.repeat(dout[:, None, :], self.L, axis=1) / self.L


class Flatten(Capa):
    def forward(self, x, entrenando=False):
        self.forma = x.shape
        return x.reshape(x.shape[0], -1)

    def backward(self, dout):
        return dout.reshape(self.forma)


class Dense(Capa):
    def __init__(self, n_in, n_out, rng):
        super().__init__()
        self.params["W"] = rng.normal(0.0, np.sqrt(2.0 / n_in), size=(n_in, n_out))
        self.params["b"] = np.zeros(n_out)

    def forward(self, x, entrenando=False):
        self.x = x
        return x @ self.params["W"] + self.params["b"]

    def backward(self, dout):
        self.grads["W"] = self.x.T @ dout
        self.grads["b"] = dout.sum(axis=0)
        return dout @ self.params["W"].T


class Dropout(Capa):
    """Apaga aleatoriamente una fracción p de neuronas solo durante el entrenamiento (dropout invertido)."""
    def __init__(self, p, rng):
        super().__init__()
        self.p, self.rng, self.mask = p, rng, None

    def forward(self, x, entrenando=False):
        if not entrenando or self.p == 0:
            self.mask = None
            return x
        self.mask = (self.rng.random(x.shape) >= self.p) / (1.0 - self.p)
        return x * self.mask

    def backward(self, dout):
        return dout if self.mask is None else dout * self.mask


class RedDosEntradas:
    """Rama temporal (capas convolucionales o Flatten) sobre la serie X (N, L, C), concatenada con las
    variables exógenas E (N, F) y seguida de una cabeza densa que devuelve un logit por muestra."""
    def __init__(self, rama, cabeza, config=None):
        self.rama, self.cabeza, self.config = rama, cabeza, config or {}

    @property
    def capas(self):
        return self.rama + self.cabeza

    def forward(self, X, E, entrenando=False):
        h = X
        for capa in self.rama:
            h = capa.forward(h, entrenando)
        self.n_rama = h.shape[1]
        h = np.concatenate([h, E], axis=1)
        for capa in self.cabeza:
            h = capa.forward(h, entrenando)
        return h[:, 0]

    def backward(self, dlogit):
        g = dlogit[:, None]
        for capa in reversed(self.cabeza):
            g = capa.backward(g)
        g = g[:, :self.n_rama]
        for capa in reversed(self.rama):
            g = capa.backward(g)
        return g

    def n_parametros(self):
        return int(sum(v.size for c in self.capas for v in c.params.values()))

    def obtener_pesos(self):
        return [{k: v.copy() for k, v in c.params.items()} for c in self.capas]

    def fijar_pesos(self, pesos):
        for capa, p in zip(self.capas, pesos):
            for k, v in p.items():
                capa.params[k] = v.copy()


def sigmoide(z):
    return 1.0 / (1.0 + np.exp(-z))


def bce_ponderada(logit, y, w):
    """Entropía cruzada binaria ponderada por clase (estable numéricamente).
    Devuelve la pérdida promedio y su derivada respecto del logit."""
    perdida_i = np.maximum(logit, 0) - logit * y + np.log1p(np.exp(-np.abs(logit)))
    perdida = np.sum(w * perdida_i) / np.sum(w)
    return perdida, w * (sigmoide(logit) - y) / np.sum(w)


class Adam:
    """Optimizador Adam (Kingma y Ba, 2015) con regularización L2 sobre los pesos W."""
    def __init__(self, modelo, lr=1e-3, beta1=0.9, beta2=0.999, eps=1e-8, l2=1e-4):
        self.modelo, self.lr, self.b1, self.b2, self.eps, self.l2, self.t = modelo, lr, beta1, beta2, eps, l2, 0
        self.m = [{k: np.zeros_like(v) for k, v in c.params.items()} for c in modelo.capas]
        self.v = [{k: np.zeros_like(v) for k, v in c.params.items()} for c in modelo.capas]

    def paso(self):
        self.t += 1
        for capa, m, v in zip(self.modelo.capas, self.m, self.v):
            for k in capa.params:
                g = capa.grads[k] + (self.l2 * capa.params[k] if k == "W" else 0.0)
                m[k] = self.b1 * m[k] + (1 - self.b1) * g
                v[k] = self.b2 * v[k] + (1 - self.b2) * g * g
                m_hat = m[k] / (1 - self.b1 ** self.t)
                v_hat = v[k] / (1 - self.b2 ** self.t)
                capa.params[k] -= self.lr * m_hat / (np.sqrt(v_hat) + self.eps)


def construir_cnn(rng, n_canales, n_exogenas, largo=72, filtros=(16, 32, 32), kernels=(5, 5, 3),
                  cabeza="gap", dropout=0.3, neuronas_densas=32):
    """CNN-1D: [Conv-ReLU-MaxPool] x2 + Conv-ReLU + (GlobalAvgPool o Flatten) + exógenas + Dense-ReLU + Dense(1)."""
    rama = [Conv1D(n_canales, filtros[0], kernels[0], rng), ReLU(), MaxPool1D(),
            Conv1D(filtros[0], filtros[1], kernels[1], rng), ReLU(), MaxPool1D(),
            Conv1D(filtros[1], filtros[2], kernels[2], rng), ReLU()]
    if cabeza == "gap":
        rama.append(GlobalAvgPool1D())
        n_rama = filtros[2]
    else:
        rama.append(Flatten())
        n_rama = (largo // 4) * filtros[2]
    cabeza_capas = [Dropout(dropout, rng), Dense(n_rama + n_exogenas, neuronas_densas, rng), ReLU(),
                    Dropout(dropout, rng), Dense(neuronas_densas, 1, rng)]
    config = dict(tipo="cnn", n_canales=n_canales, n_exogenas=n_exogenas, largo=largo, filtros=list(filtros),
                  kernels=list(kernels), cabeza=cabeza, dropout=dropout, neuronas_densas=neuronas_densas)
    return RedDosEntradas(rama, cabeza_capas, config)


def construir_mlp(rng, n_canales, n_exogenas, largo=72, ocultas=(64, 32), dropout=0.3):
    """Perceptrón multicapa sobre la ventana aplanada (misma información de entrada que la CNN, sin convolución)."""
    cabeza = [Dense(largo * n_canales + n_exogenas, ocultas[0], rng), ReLU(), Dropout(dropout, rng),
              Dense(ocultas[0], ocultas[1], rng), ReLU(), Dropout(dropout, rng), Dense(ocultas[1], 1, rng)]
    config = dict(tipo="mlp", n_canales=n_canales, n_exogenas=n_exogenas, largo=largo, ocultas=list(ocultas), dropout=dropout)
    return RedDosEntradas([Flatten()], cabeza, config)


def predecir_proba(modelo, X, E, lote=2048):
    """Probabilidad de excedencia para cada muestra (modo evaluación: sin dropout)."""
    z = np.concatenate([modelo.forward(X[k:k + lote], E[k:k + lote], entrenando=False) for k in range(0, len(X), lote)])
    return sigmoide(z)


def entrenar(constructor, X_tr, E_tr, y_tr, X_va, E_va, y_va, semilla, epocas=100, lote=128, lr=1e-3,
             l2=1e-4, paciencia=15):
    """Entrena con mini-lotes, pérdida ponderada por clase y parada temprana según el AP de validación.
    Devuelve el modelo con los pesos de la mejor época, el historial, la mejor época y su AP de validación."""
    rng = np.random.default_rng(semilla)
    modelo = constructor(rng)
    opt = Adam(modelo, lr=lr, l2=l2)
    n, n_pos = len(y_tr), y_tr.sum()
    w_pos, w_neg = n / (2 * n_pos), n / (2 * (n - n_pos))           # pesos de clase "balanced"
    w_tr, w_va = np.where(y_tr == 1, w_pos, w_neg), np.where(y_va == 1, w_pos, w_neg)
    historial, mejor, espera = [], {"ap": -np.inf, "epoca": 0, "pesos": None}, 0
    for epoca in range(1, epocas + 1):
        orden, perdida_total = rng.permutation(n), 0.0
        for k in range(0, n, lote):
            b = orden[k:k + lote]
            logit = modelo.forward(X_tr[b], E_tr[b], entrenando=True)
            perdida, dlogit = bce_ponderada(logit, y_tr[b], w_tr[b])
            modelo.backward(dlogit)
            opt.paso()
            perdida_total += perdida * len(b)
        logit_va = np.concatenate([modelo.forward(X_va[k:k + 2048], E_va[k:k + 2048]) for k in range(0, len(X_va), 2048)])
        perdida_va = bce_ponderada(logit_va, y_va, w_va)[0]
        ap_va = average_precision_score(y_va, sigmoide(logit_va))
        historial.append({"epoca": epoca, "perdida_entrenamiento": perdida_total / n,
                          "perdida_validacion": perdida_va, "AP_validacion": ap_va})
        if ap_va > mejor["ap"] + 1e-4:
            mejor, espera = {"ap": ap_va, "epoca": epoca, "pesos": modelo.obtener_pesos()}, 0
        else:
            espera += 1
            if espera >= paciencia:
                break
    modelo.fijar_pesos(mejor["pesos"])
    return modelo, pd.DataFrame(historial), mejor["epoca"], mejor["ap"]


def guardar_modelo(modelo, ruta_npz, metadatos):
    """Guarda pesos (.npz) y configuración/metadatos (.json) para reutilizar el modelo fuera del notebook."""
    arrays = {f"capa{i}_{k}": v for i, c in enumerate(modelo.capas) for k, v in c.params.items()}
    for k, v in metadatos.items():
        if isinstance(v, np.ndarray):
            arrays[f"meta_{k}"] = v
    np.savez(ruta_npz, **arrays)
    info = {"config": modelo.config, **{k: v for k, v in metadatos.items() if not isinstance(v, np.ndarray)}}
    with open(ruta_npz.replace(".npz", ".json"), "w", encoding="utf-8") as f:
        json.dump(info, f, ensure_ascii=False, indent=2)


def cargar_modelo(ruta_npz):
    """Reconstruye la red a partir del .json de configuración y carga los pesos del .npz."""
    with open(ruta_npz.replace(".npz", ".json"), encoding="utf-8") as f:
        info = json.load(f)
    cfg = dict(info["config"])
    tipo = cfg.pop("tipo")
    rng = np.random.default_rng(0)
    modelo = construir_cnn(rng, **cfg) if tipo == "cnn" else construir_mlp(rng, **cfg)
    datos = np.load(ruta_npz)
    for i, capa in enumerate(modelo.capas):
        for k in capa.params:
            capa.params[k] = datos[f"capa{i}_{k}"]
    extras = {k[5:]: datos[k] for k in datos.files if k.startswith("meta_")}
    return modelo, {**info, **extras}
