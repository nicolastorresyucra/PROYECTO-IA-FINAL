'''Prototipo del sistema de alerta temprana de PM10 (CNN-1D) — interfaz de línea de comandos.

Uso:
    python prototipo/alerta_pm10.py --csv "<CSV del SENAMHI>" --fecha 2022-07-20

Para cada estación usa SOLO las 72 horas anteriores al día indicado y estima la probabilidad de que la
media diaria de PM10 supere el ECA (100 ug/m3). Guarda el boletín en resultados/boletin_alerta_<fecha>.csv
'''
import argparse, os, sys, time
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
import numpy as np
import pandas as pd
import src.datos_aire as da
import src.cnn1d_numpy as cnn


def nivel_alerta(p, umbral):
    if p >= umbral:
        return "ROJO - alerta de excedencia"
    if p >= umbral / 2:
        return "AMARILLO - vigilancia"
    return "VERDE - sin alerta"


def emitir_boletin(A, estaciones, dias, fecha, modelo, meta):
    filas = []
    for i, est in enumerate(estaciones):
        v = da.ventana_para_fecha(A, dias, i, fecha)
        if v is None or np.isfinite(v[:, 0]).sum() < da.MIN_HORAS_PM10_VENTANA:
            filas.append({"estacion": est, "probabilidad": np.nan, "nivel": "SIN DATOS SUFICIENTES"})
            continue
        x = da.transformar_ventanas(v[None], meta["medias"], meta["desv"])
        e = da.variables_exogenas([fecha], [i], len(estaciones))
        p = float(cnn.predecir_proba(modelo, x, e)[0])
        filas.append({"estacion": est, "probabilidad": round(p, 3), "nivel": nivel_alerta(p, meta["umbral"])})
    return pd.DataFrame(filas)


def main():
    parser = argparse.ArgumentParser(description="Boletín de alerta temprana de PM10 (CNN-1D)")
    parser.add_argument("--csv", required=True, help="CSV oficial del SENAMHI")
    parser.add_argument("--fecha", required=True, help="día a pronosticar (AAAA-MM-DD)")
    parser.add_argument("--modelo", default=os.path.join(RAIZ, "modelos", "cnn1d_alerta_pm10.npz"))
    args = parser.parse_args()
    t0 = time.time()
    modelo, meta = cnn.cargar_modelo(args.modelo)
    df, _ = da.limpiar_datos(pd.read_csv(args.csv, low_memory=False))
    A, estaciones, dias = da.construir_arreglo_horario(df)
    if list(estaciones) != list(meta["estaciones"]):
        sys.exit("Las estaciones del CSV no coinciden con las del modelo.")
    fecha = pd.Timestamp(args.fecha)
    boletin = emitir_boletin(A, estaciones, dias, fecha, modelo, meta)
    print(f"BOLETÍN DE ALERTA TEMPRANA DE PM10 - día pronosticado: {fecha.date()} (alerta si P >= {meta['umbral']:.3f})")
    print(boletin.to_string(index=False))
    os.makedirs(os.path.join(RAIZ, "resultados"), exist_ok=True)
    salida = os.path.join(RAIZ, "resultados", f"boletin_alerta_{fecha.date()}.csv")
    boletin.to_csv(salida, index=False)
    print(f"Boletín guardado en {salida} | tiempo total: {time.time() - t0:.1f} s")


if __name__ == "__main__":
    main()